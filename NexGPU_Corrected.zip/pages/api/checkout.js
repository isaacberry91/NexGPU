export default function handler(req, res) {
  res.status(200).json({ message: 'Stripe checkout will go here.' });
}