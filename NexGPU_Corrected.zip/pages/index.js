export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      <h1>Welcome to NexGPU</h1>
      <p>Rent cloud GPUs and servers by the hour.</p>
    </div>
  );
}